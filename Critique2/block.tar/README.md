# Critique2 

## File Structure 



## TODO
* Write Inc function in more general way 
* GHASH, if last block is not complete 128-bit 
* What is support for the lengths ?? 