package utils 

var Key []byte = []byte("0123456789abcdef") // 16 bytes = AES-128
var TagLength int = 128 